# ifits-utils

ifits-utils provides all kinds of tools for ifits project.

## Documentation

Detailed documentation on [GitHub Wiki](https://github.intel.com/ft/ifits-utils/wiki).

## Installation

Installation fron source codes:
    python setup.py install

## Usage

## Features

* Update Excel files with specific test data.

## Future Plans

## Latest Changes

## License

Copyright &copy; 2017

Intel FT TECH
