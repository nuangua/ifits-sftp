#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals, print_function

import os
from ifits_utils import config

# create file with specific filesize, the unit is Byte
def get_or_create_file(filesize, filename=None):
    if not filename:
        filename = "filesize_as_%s.txt" % (str(filesize))
    filepath = os.path.join(config.DATA_FILES_PATH, filename)
    if not os.path.exists(filepath) or os.stat(filepath).st_size != filesize:
        with open(filepath, "wb") as file:
            file.truncate(filesize)
    return filepath

if __name__ == "__main__":
    print(get_or_create_file(2*1024*1024, "test.txt"))