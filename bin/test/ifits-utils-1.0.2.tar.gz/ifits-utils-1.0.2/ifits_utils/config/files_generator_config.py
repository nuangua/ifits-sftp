#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import os

BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# files_generator
DATA_FILES_PATH = os.path.join(BASE_PATH, "data_files")
if not os.path.exists(DATA_FILES_PATH):
    os.makedirs(DATA_FILES_PATH, 0755)

THIRDPARTY_PATH = os.path.join(BASE_PATH, "thirdparty")
EXPECT_PATH = os.path.join(THIRDPARTY_PATH, "expect")
EXPECT_EXEC_PATH = os.path.join(THIRDPARTY_PATH, "expect","expect.exe")