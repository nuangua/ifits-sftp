#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from ifits_utils.config.files_generator_config import *