#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


TEMPLATES_DIR = os.path.join(BASE_DIR, "excel", "templates")
TEMPLATE_NAME = "XMM7560_MSIM_FT_China_Cycle3_Results_Overview_V1.xlsm"
TEMPLATE_NAME2 = "XMM7560_MSIM_FT_China_Cycle3_Results_Overview_V1_mod.xlsm"
TEMPLATE_FILE_PATH = os.path.join(TEMPLATES_DIR, TEMPLATE_NAME)
TEMPLATE_FILE_PATH2 = os.path.join(TEMPLATES_DIR, TEMPLATE_NAME2)

# template layout data
SHEET_NAME_CHINA_MOMT = "KPI-Dashboard-China-MOMT"
SHEET_NAME_CHINA_LONGCA = "KPI-Dashboard-China-LongCa"
SHEET_NAME_CHINA_DATA = "KPI-Dashboard-China-Data"

SHEET_NAME_LIST = [
    SHEET_NAME_CHINA_MOMT,
    SHEET_NAME_CHINA_LONGCA,
    SHEET_NAME_CHINA_DATA,
]

SHEET_NAME_LABEL = "SHEET_NAME"
LAYOUT_LABEL = "LAYOUT"

HEADER_LABEL = "HEADER"
POSITION_LABEL = "POSITION"
MODE_LABEL = "MODE"
SPACENUM_LABEL = "SPACENUM"

def convert(char):
    return ord(char.upper()) - 64

HEADER_LIST = [
    r"TC ID",
    r"TC Headline",
    r"Combs",
    r"Operator\npysical SIM slot1-pysical SIM slot2",
    r"RAT\npysical SIM slot1-pysical SIM slot2",
    r"Infra\npysical SIM slot1-pysical SIM slot2",
    r"City"
]

MOMT_DATA = {
    HEADER_LIST[0]: r"FT_KPI-EIC-MSIM-2.2.1.m",
    HEADER_LIST[1]: r"(SIM1-Idle/SIM2-Idle) Alternative MT Short Voice Calls (Mobility)",
    HEADER_LIST[2]: r"4G-4G",
    HEADER_LIST[3]: r"CMCC-CMCC",
    HEADER_LIST[4]: r"TDD VoLTE-TDD CSFB",
    HEADER_LIST[5]: r"E///-E///",
    HEADER_LIST[6]: "Dezhou",
    "DATA": [-0.1, -0.15]
}

LAYOUT_CHINA_MOMT = [
    {
        POSITION_LABEL: [14, "A"],
        HEADER_LABEL: r"TC ID",
        MODE_LABEL: "COLUMN",
        SPACENUM_LABEL: 0,
    },
    {
        POSITION_LABEL: [14, "B"],
        HEADER_LABEL: r"TC Headline",
        MODE_LABEL: "COLUMN",
        SPACENUM_LABEL: 0,
    },
    {
        POSITION_LABEL: [1, "H"],
        HEADER_LABEL: r"Combs",
        MODE_LABEL: "ROW",
        SPACENUM_LABEL: 1,
    },
    {
        POSITION_LABEL: [2, "H"],
        HEADER_LABEL: r"Operator\npysical SIM slot1-pysical SIM slot2",
        MODE_LABEL: "ROW",
        SPACENUM_LABEL: 1,
    },
    {
        POSITION_LABEL: [3, "H"],
        HEADER_LABEL: r"RAT\npysical SIM slot1-pysical SIM slot2",
        MODE_LABEL: "ROW",
        SPACENUM_LABEL: 1,
    },
    {
        POSITION_LABEL: [4, "H"],
        HEADER_LABEL: r"Infra\npysical SIM slot1-pysical SIM slot2",
        MODE_LABEL: "ROW",
        SPACENUM_LABEL: 1,
    },
    {
        POSITION_LABEL: [5, "H"],
        HEADER_LABEL: r"City",
        MODE_LABEL: "ROW",
        SPACENUM_LABEL: 1,
    }
]

TEMPLATE_LAYOUT = [
    {
        SHEET_NAME_LABEL: SHEET_NAME_CHINA_MOMT,
        LAYOUT_LABEL:  LAYOUT_CHINA_MOMT
    }
]
