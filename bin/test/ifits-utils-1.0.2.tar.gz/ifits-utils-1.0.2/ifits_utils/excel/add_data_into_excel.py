from ifits_utils.excel import settings
import json
import os
import xlrd
import xlwt
from xlutils.copy import copy
import pandas as pd

from openpyxl import load_workbook
from openpyxl import Workbook
from openpyxl.chart import BarChart, Series, Reference, BarChart3D
from openpyxl.styles import Color, Font, Alignment
from openpyxl.styles.colors import BLUE, RED, GREEN, YELLOW

def check_layout(sheet, layout):
    for item in layout:
        position = item[settings.POSITION_LABEL]
        header = item[settings.HEADER_LABEL]
        mode = item[settings.MODE_LABEL]
        spacenum = item[settings.SPACENUM_LABEL]
        if header.strip() == sheet[str(position[1])+str(position[0])].value.strip():
            print(False)
            return False
    print(True)
    return True

def insert_data(read_sheet, write_sheet, layout, data):
    row_num = read_sheet.max_row
    col_num = read_sheet.max_column
    occur_list = []
    for item in layout:
        position = item[settings.POSITION_LABEL]
        header = item[settings.HEADER_LABEL]
        mode = item[settings.MODE_LABEL]
        spacenum = item[settings.SPACENUM_LABEL]
        if mode == r"COLUMN":
            data_set = set()
            for index in range(position[0], row_num):
                if header.strip() in data and read_sheet[str(position[1])+str(index)].strip() == data[header.strip()]:
                    data_set.add(index)
            _data = {"mode": mode, "set": data_set, "position":position}
            occur_list.append(_data)
        elif mode == r"ROW":
            data_set = set()
            for index in range(settings.convert(position[1]), col_num):
                print(read_sheet[str(chr(index+64))+str(position[0])].strip())
                print(data)
                print(header.strip())
                if header.strip() in data and read_sheet[str(chr(index))+str(position[0])].strip() == data[header.strip()]:
                    data_set.add(str(chr(index+64)))
            _data = {"mode": mode, "set": data_set, "position": position}
            occur_list.append(_data)

    row_set = set()
    col_set = set()
    for occur in occur_list:
        if occur["mode"] == r"COLUMN":
            if len(row_set) == 0:
                row_set = occur["set"]
            else:
                row_set = row_set.intersection(occur["set"])
        elif occur["mode"] == r"ROW":
            if len(col_set) == 0:
                col_set = occur["set"]
            else:
                col_set = col_set.intersection(occur["set"])
    print("occur_list=%s" % (occur_list))
    print("row_set=%s" % (row_set))
    print("col_set=%s" % (col_set))
    if len(row_set) == 1 and len(col_set) == 1:
        row_num = row_set.pop()
        col_num = col_set.pop()
        # write_sheet.write(row_num, col_num, data["DATA"][0])
        # write_sheet.write(row_num, col_num+1, data["DATA"][1])
        # write_sheet.cell(str(col_num)+str(row_num)).value = data["DATA"][0]
        # write_sheet.cell(str(chr(settings.convert(col_num)+1+64)) + str(row_num)).value = data["DATA"][1]

def handle_call_sheet(read_sheet, write_sheet, layout, data):
    print("handle_call_sheet")
    if check_layout(read_sheet, layout):
        insert_data(read_sheet, write_sheet, layout, data)
    pass

def handle_data_sheet(sheet):
    row_num = sheet.nrows
    col_num = sheet.ncols
    print(row_num)
    print(col_num)
    for i in range(0, col_num):
        #sheet.cell_value(1,2)
        col_ata = sheet.col_values(i)
        print(col_ata)
    pass

if __name__ == "__main__":
    BOOK_FILE_PATH = settings.TEMPLATE_FILE_PATH
    BOOK_FILE_PATH2 = settings.TEMPLATE_FILE_PATH2

    # read_book = xlrd.open_workbook(BOOK_FILE_PATH)
    # sheet_list = read_book.sheet_names()
    # write_book = copy(read_book)

    read_book = load_workbook(BOOK_FILE_PATH)
    sheet_list = read_book.get_sheet_names()
    write_book = read_book
    write_sheet = write_book.active

    # print(json.dumps(sheet_list))
    for sheet_name in sheet_list:
        for item in settings.TEMPLATE_LAYOUT:
            if sheet_name ==item[settings.SHEET_NAME_LABEL]:
                layout = item[settings.LAYOUT_LABEL]
                read_sheet = read_book.get_sheet_by_name(sheet_name)
                handle_call_sheet(read_sheet, write_sheet, layout, settings.MOMT_DATA)

    # os.remove(BOOK_FILE_PATH)
    write_book.save(BOOK_FILE_PATH2)