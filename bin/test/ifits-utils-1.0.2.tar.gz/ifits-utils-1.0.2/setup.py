#!/usr/bin/env python

from os.path import exists, join
from setuptools import setup, find_packages
import os

SCRIPTS = []
#SCRIPTS = [join('bin', s) for s in ['ifits-utils']]

if os.name == "nt":
    SCRIPTS = [s+'.bat' for s in SCRIPTS]
elif os.name == "posix":
    SCRIPTS = [s + '.sh' for s in SCRIPTS]

setup(
    name='ifits-utils',
    version=open('VERSION').read().strip(),
    author='David Koo',
    author_email='nuanguang.gu@intel.com',
    packages=find_packages(),
    scripts=SCRIPTS,
    url='https://github.intel.com/ft/ifits-utils',
    license='Intel FT TECH',
    description='ifits-utils',
    long_description=open('README.rst').read() if exists("README.rst") else "",
    include_package_data=True,
    # Any requirements here
    install_requires=[
        'pysftp',
        'idata-security',
    ],
    python_requires=">=2.7, !=3.0.*, !=3.1.*, !=3.2.*, !=3.3.*",
)